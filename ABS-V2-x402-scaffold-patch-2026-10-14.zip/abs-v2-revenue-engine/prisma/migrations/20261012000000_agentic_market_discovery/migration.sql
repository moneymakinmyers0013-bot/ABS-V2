CREATE TABLE "MarketLead" (
  "id" TEXT NOT NULL,
  "sourceKey" TEXT NOT NULL,
  "externalId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "taskType" TEXT,
  "description" TEXT,
  "sourceUrl" TEXT NOT NULL,
  "claimUrl" TEXT,
  "rewardCents" INTEGER,
  "currency" TEXT NOT NULL DEFAULT 'USD',
  "payload" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'DISCOVERED',
  "rejectionReason" TEXT,
  "discoveredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "MarketLead_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "MarketLead_sourceKey_externalId_key" ON "MarketLead"("sourceKey", "externalId");
CREATE INDEX "MarketLead_status_discoveredAt_idx" ON "MarketLead"("status", "discoveredAt");
CREATE INDEX "MarketLead_taskType_rewardCents_idx" ON "MarketLead"("taskType", "rewardCents");

CREATE TABLE "AgentRequest" (
  "id" TEXT NOT NULL,
  "idempotencyKey" TEXT NOT NULL,
  "requestHash" TEXT NOT NULL,
  "buyerEmail" TEXT NOT NULL,
  "taskId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AgentRequest_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "AgentRequest_idempotencyKey_key" ON "AgentRequest"("idempotencyKey");
CREATE UNIQUE INDEX "AgentRequest_taskId_key" ON "AgentRequest"("taskId");
CREATE INDEX "AgentRequest_buyerEmail_createdAt_idx" ON "AgentRequest"("buyerEmail", "createdAt");
